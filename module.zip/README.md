# Feiticeiros e Maldições
*Feito com Custom System Builder*

Módulo não-oficial para o sistema de Feiticeiros e Maldições feito por Setsugiri.

## Como Instalar

1. Instale o módulo usando o manifest link na sessão "instalar módulo" no Foundry: https://raw.githubusercontent.com/Kyodan061/Feiticeiros-e-Maldicoes-CSB/main/module.json
2. 

